﻿using System;

namespace Client
{
    public class Class1
    {
    }
}
