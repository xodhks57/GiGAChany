﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;
using System.Drawing.Imaging;
using System.Threading;
using System.IO;

namespace FaceClient
{
    public partial class Form1 : Form
    {
        byte[] startMsg = Encoding.UTF8.GetBytes("Start");
        Socket clientSocket;
        Thread t_handler;
        Thread t_handler2;
        string m_splitter = "'\\'";
        public string m_fName = string.Empty;
        string[] m_split = null;
        public string Filepath;

        delegate void AppendTextDelegate(Control ctrl, string s);
        enum DataPacketType { TEXT = 1, image };
        //private delegate void AddTextDelegate(string strText);
        public Form1()
        {
            InitializeComponent();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            char[] delimeter = m_splitter.ToCharArray();

            /*OpenFileDialog openFile = new OpenFileDialog();
            openFile.DefaultExt = "jpg";
            //this.openFile.Filter = "Image files (*.jpg, *.jpeg, *.jpe, *.jfif, *.png) | *.jpg; *.jpeg; *.jpe; *.jfif; *.png";
            this.openFile.Filter = "Graphics interchange Format (*.jpg)|*.jpg|All files(*.*)|*.*";
            this.openFile.ShowDialog();*/

            openFile.Filter = "Image files (*.jpg, *.jpeg, *.jpe, *.jfif, *.png) | *.jpg; *.jpeg; *.jpe; *.jfif; *.png";
            openFile.ShowDialog();
            Image image = Image.FromFile(openFile.FileName);
            Filepath = this.openFile.FileName;
            pictureBox1.ImageLocation = this.openFile.FileName;

            m_split = Filepath.Split(delimeter);
            int limit = m_split.Length;

            m_fName = m_split[limit - 1].ToString();

            if (Filepath != null)
                button2.Enabled = true;
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            button2.Enabled = false;

            clientSocket.Send(startMsg);
            t_handler = new Thread(SendData);
            t_handler2 = new Thread(RecvData);
            t_handler.IsBackground = true;
            t_handler2.IsBackground = true;
            t_handler.Start();
            t_handler2.Start();
        }

        public void SendData()
        {
            while (true)
            {
                FileStream fileStr = new FileStream(Filepath, FileMode.Open, FileAccess.Read);
                int count = (int)fileStr.Length / 1024 + 1;
                BinaryReader reader = new BinaryReader(fileStr);
                //int fileLength = (int)fileStr.Length;
                for (int i = 0; i < count; i++)
                {
                    byte[] buffer = reader.ReadBytes(1024);
                    clientSocket.Send(buffer);
                }
                t_handler.Abort();
            }
        }

        public void RecvData()
        {
            while (true)
            {
                //연결된 클라이언트가 보낸 데이터 수신
                byte[] receiveBuffer = new byte[1024];
                int length = clientSocket.Receive(
                receiveBuffer, receiveBuffer.Length, SocketFlags.None
                );
                string msg = Encoding.UTF8.GetString(receiveBuffer);
                /*this.Invoke(new Action(
                    delegate ()
                    {
                        textBox2.Text = msg;
                    }));*/
                string[] Answer = msg.Split(new char[] { '^' });
                if (Answer[0] == "male")
                {
                    label1.Text = "Male";
                    label2.Text = Answer[1] + "%";
                }
                else if(Answer[0] == "female")
                {
                    label1.Text = "Female";
                    label2.Text = Answer[1] + "%";
                }
                else if(Answer[0] == "fail")
                {
                    label1.Text = "Sorry,";
                    label2.Text = "Fail";
                }
                t_handler2.Abort();
                button2.Enabled = true;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            //clientSocket.Connect(IPAddress.Parse("192.36.90.230"), 9080);
            //clientSocket.Connect(IPAddress.Parse("10.10.20.253"), 9076);


            label1.BackColor = Color.Transparent;
            label1.Parent = pictureBox2;
            label2.BackColor = Color.Transparent;
            label2.Parent = pictureBox2;
            label1.BringToFront();
            label2.BringToFront();
        }

    private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            //clientSocket.Close();
        }
    }
}